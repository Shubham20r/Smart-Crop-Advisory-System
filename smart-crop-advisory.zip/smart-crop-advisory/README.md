# Smart Crop Advisory System - किसान मित्र
## MVP for Small and Marginal Farmers

A multilingual, AI-based advisory system designed to help small and marginal farmers in India make informed decisions about crop selection, pest control, and fertilizer use.

## Features

### 🌱 **Crop Recommendations**
- Personalized crop suggestions based on:
  - Soil type (loamy, clay, sandy, black soil, alluvial)
  - Season (Kharif, Rabi, Summer)
  - Water availability
  - Previous crop history
  - Location-specific factors

### ☁️ **Weather Alerts & Advisory**
- Real-time weather information
- Agricultural alerts for extreme conditions
- Activity recommendations based on weather
- Risk assessment for pests and diseases

### 🐛 **Pest Detection**
- Image-based pest identification
- Treatment recommendations (organic and chemical)
- Prevention strategies
- Severity assessment

### 💊 **Fertilizer Recommendations**
- NPK recommendations based on:
  - Crop type
  - Growth stage
  - Soil nutrient status
- Organic alternatives
- Application methods and precautions

### 💰 **Market Price Information**
- Current market prices for major crops
- Price trends and analysis

### 🌐 **Multilingual Support**
- Available in English and Hindi (हिंदी)
- Easy language switching
- Voice support planned for future

## Technology Stack

- **Backend**: Node.js, Express.js
- **Frontend**: HTML5, CSS3, JavaScript (Vanilla)
- **Database**: In-memory (MVP) - can be upgraded to MongoDB/PostgreSQL
- **Deployment**: Can be deployed on Heroku, AWS, or local server

## Installation & Setup

### Prerequisites
- Node.js (v14 or higher)
- npm (Node Package Manager)

### Backend Setup

1. Navigate to the backend directory:
```bash
cd smart-crop-advisory/backend
```

2. Install dependencies:
```bash
npm install
```

3. Start the server:
```bash
npm start
```

The backend server will run on `http://localhost:5000`

### Frontend Setup

1. Navigate to the frontend directory:
```bash
cd smart-crop-advisory/frontend
```

2. Open `index.html` in a web browser, or serve it using a local server:

Using Python:
```bash
python -m http.server 8080
```

Or using Node.js http-server:
```bash
npx http-server -p 8080
```

3. Access the application at `http://localhost:8080`

## Usage Guide

### For Farmers

1. **Select Language**: Choose between English or हिंदी
2. **Navigate Tabs**: Use the navigation tabs to access different features
3. **Fill Forms**: Enter your farm details in the respective forms
4. **Get Recommendations**: Submit forms to receive personalized advice
5. **Save Results**: Take screenshots or notes of recommendations

### For Administrators/Developers

1. **API Endpoints**:
   - `POST /api/crop-recommendation` - Get crop recommendations
   - `GET /api/weather/:location` - Get weather data
   - `POST /api/pest-detection` - Upload image for pest detection
   - `POST /api/fertilizer-recommendation` - Get fertilizer advice
   - `GET /api/market-prices/:crop` - Get market prices

2. **Customization**:
   - Update crop database in `backend/controllers/cropRecommendation.js`
   - Add more languages in `backend/utils/translations.js`
   - Modify weather locations in `backend/controllers/weatherService.js`

## Project Structure

```
smart-crop-advisory/
├── backend/
│   ├── controllers/
│   │   ├── cropRecommendation.js
│   │   ├── weatherService.js
│   │   └── pestDetection.js
│   ├── utils/
│   │   └── translations.js
│   ├── server.js
│   └── package.json
├── frontend/
│   ├── index.html
│   ├── styles.css
│   └── app.js
├── data/
│   └── (future: database files)
└── README.md
```

## Future Enhancements

1. **Voice Input/Output**: Voice commands and text-to-speech for low-literate users
2. **AI/ML Integration**: 
   - Real pest detection using TensorFlow.js
   - Predictive analytics for crop yield
3. **Real Weather API**: Integration with OpenWeatherMap or IMD
4. **Database Integration**: MongoDB for data persistence
5. **Mobile App**: React Native or Flutter app
6. **SMS Integration**: SMS-based advisory for non-smartphone users
7. **Community Features**: Farmer forums and knowledge sharing
8. **Government Scheme Integration**: Information about subsidies and schemes
9. **Offline Mode**: PWA with offline capabilities
10. **Analytics Dashboard**: For agricultural officers and policymakers

## Contributing

We welcome contributions! Please follow these steps:

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## Support

For issues or questions:
- Create an issue on GitHub
- Contact: [support email]

## License

This project is open-source and available under the MIT License.

## Acknowledgments

- Government of Punjab - Department of Higher Education
- Small and marginal farmers of India
- Agricultural extension officers
- Open-source community

---

**Note**: This is an MVP (Minimum Viable Product) designed for demonstration and testing. Production deployment would require additional features like authentication, data validation, real API integrations, and security measures.

## Quick Test Guide

1. **Test Crop Recommendation**:
   - Soil Type: Loamy
   - Season: Kharif
   - Location: Punjab
   - Water: Medium
   - Submit to see recommendations

2. **Test Weather**:
   - Enter "Punjab" or "Haryana"
   - View weather alerts and agricultural advisory

3. **Test Pest Detection**:
   - Upload any plant/leaf image
   - System will simulate pest detection

4. **Test Fertilizer**:
   - Select Wheat crop
   - Choose Sowing stage
   - Get NPK recommendations

5. **Test Market Prices**:
   - Select any crop
   - View current market prices

---

**किसान मित्र** - Empowering farmers with technology! 🌾
