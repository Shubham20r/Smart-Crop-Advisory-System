// Translation utility for multilingual support
// Supports English and Hindi for MVP

const translations = {
  // Common terms
  wheat: { en: 'Wheat', hi: 'गेहूं' },
  rice: { en: 'Rice', hi: 'चावल' },
  cotton: { en: 'Cotton', hi: 'कपास' },
  sugarcane: { en: 'Sugarcane', hi: 'गन्ना' },
  maize: { en: 'Maize', hi: 'मक्का' },
  pulses: { en: 'Pulses', hi: 'दालें' },
  vegetables: { en: 'Vegetables', hi: 'सब्जियां' },
  
  // Soil types
  loamy: { en: 'Loamy', hi: 'दोमट' },
  clay: { en: 'Clay', hi: 'चिकनी मिट्टी' },
  sandy: { en: 'Sandy', hi: 'रेतीली' },
  'black soil': { en: 'Black Soil', hi: 'काली मिट्टी' },
  alluvial: { en: 'Alluvial', hi: 'जलोढ़' },
  
  // Seasons
  kharif: { en: 'Kharif', hi: 'खरीफ' },
  rabi: { en: 'Rabi', hi: 'रबी' },
  summer: { en: 'Summer', hi: 'गर्मी' },
  winter: { en: 'Winter', hi: 'सर्दी' },
  
  // Water availability
  high: { en: 'High', hi: 'उच्च' },
  medium: { en: 'Medium', hi: 'मध्यम' },
  low: { en: 'Low', hi: 'कम' },
  
  // Common phrases
  recommendations: { en: 'Recommendations', hi: 'सिफारिशें' },
  suitabilityScore: { en: 'Suitability Score', hi: 'उपयुक्तता स्कोर' },
  growthDuration: { en: 'Growth Duration', hi: 'विकास अवधि' },
  waterRequirement: { en: 'Water Requirement', hi: 'पानी की आवश्यकता' },
  idealTemperature: { en: 'Ideal Temperature', hi: 'आदर्श तापमान' },
  advisoryNotes: { en: 'Advisory Notes', hi: 'सलाहकार नोट्स' },
  
  // Weather terms
  temperature: { en: 'Temperature', hi: 'तापमान' },
  humidity: { en: 'Humidity', hi: 'नमी' },
  rainfall: { en: 'Rainfall', hi: 'वर्षा' },
  windSpeed: { en: 'Wind Speed', hi: 'हवा की गति' },
  forecast: { en: 'Forecast', hi: 'पूर्वानुमान' },
  alerts: { en: 'Alerts', hi: 'चेतावनी' },
  
  // Pest terms
  pest: { en: 'Pest', hi: 'कीट' },
  disease: { en: 'Disease', hi: 'रोग' },
  treatment: { en: 'Treatment', hi: 'उपचार' },
  organic: { en: 'Organic', hi: 'जैविक' },
  chemical: { en: 'Chemical', hi: 'रासायनिक' },
  prevention: { en: 'Prevention', hi: 'रोकथाम' },
  symptoms: { en: 'Symptoms', hi: 'लक्षण' },
  
  // Advisory messages
  'Test your soil before planting for optimal results': {
    en: 'Test your soil before planting for optimal results',
    hi: 'बेहतर परिणामों के लिए रोपण से पहले अपनी मिट्टी की जांच करें'
  },
  'Consider local market demand for selected crops': {
    en: 'Consider local market demand for selected crops',
    hi: 'चयनित फसलों के लिए स्थानीय बाजार की मांग पर विचार करें'
  },
  'Ensure proper seed quality from certified vendors': {
    en: 'Ensure proper seed quality from certified vendors',
    hi: 'प्रमाणित विक्रेताओं से उचित बीज गुणवत्ता सुनिश्चित करें'
  },
  'Monitor weather forecasts regularly': {
    en: 'Monitor weather forecasts regularly',
    hi: 'मौसम पूर्वानुमान की नियमित निगरानी करें'
  },
  
  // Fertilizer terms
  nitrogen: { en: 'Nitrogen', hi: 'नाइट्रोजन' },
  phosphorus: { en: 'Phosphorus', hi: 'फास्फोरस' },
  potassium: { en: 'Potassium', hi: 'पोटेशियम' },
  'kg/hectare': { en: 'kg/hectare', hi: 'किलो/हेक्टेयर' },
  
  // Common pests
  aphids: { en: 'Aphids', hi: 'एफिड्स' },
  whitefly: { en: 'Whitefly', hi: 'सफेद मक्खी' },
  bollworm: { en: 'Bollworm', hi: 'बॉलवर्म' },
  
  // Actions
  apply: { en: 'Apply', hi: 'लागू करें' },
  monitor: { en: 'Monitor', hi: 'निगरानी करें' },
  harvest: { en: 'Harvest', hi: 'कटाई' },
  sowing: { en: 'Sowing', hi: 'बुवाई' },
  irrigation: { en: 'Irrigation', hi: 'सिंचाई' }
};

const translate = (data, language = 'en') => {
  if (language === 'en') {
    return data; // Return as-is for English
  }
  
  // Deep clone the object to avoid modifying original
  const translated = JSON.parse(JSON.stringify(data));
  
  // Recursive function to translate all string values
  const translateObject = (obj) => {
    for (const key in obj) {
      if (typeof obj[key] === 'string') {
        // Try to find translation
        const lowerKey = obj[key].toLowerCase();
        if (translations[lowerKey] && translations[lowerKey][language]) {
          obj[key] = translations[lowerKey][language];
        } else if (translations[key] && translations[key][language]) {
          // Try key itself
          obj[key] = translations[key][language];
        }
        // If no translation found, keep original
      } else if (Array.isArray(obj[key])) {
        obj[key] = obj[key].map(item => {
          if (typeof item === 'string') {
            const lowerItem = item.toLowerCase();
            if (translations[lowerItem] && translations[lowerItem][language]) {
              return translations[lowerItem][language];
            }
            // Check if it's a phrase
            if (translations[item] && translations[item][language]) {
              return translations[item][language];
            }
            return item;
          } else if (typeof item === 'object') {
            translateObject(item);
            return item;
          }
          return item;
        });
      } else if (typeof obj[key] === 'object' && obj[key] !== null) {
        translateObject(obj[key]);
      }
    }
  };
  
  translateObject(translated);
  
  // Also translate keys if they have translations
  const translateKeys = (obj) => {
    const newObj = {};
    for (const key in obj) {
      let newKey = key;
      if (translations[key] && translations[key][language]) {
        newKey = translations[key][language];
      }
      if (typeof obj[key] === 'object' && obj[key] !== null && !Array.isArray(obj[key])) {
        newObj[newKey] = translateKeys(obj[key]);
      } else {
        newObj[newKey] = obj[key];
      }
    }
    return newObj;
  };
  
  return translateKeys(translated);
};

module.exports = {
  translate,
  translations
};
