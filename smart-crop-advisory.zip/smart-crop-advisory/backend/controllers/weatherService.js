// Weather service with mock data for MVP
// In production, this would integrate with a real weather API like OpenWeatherMap

const getWeatherAlerts = async (location) => {
  // Mock weather data for demonstration
  // In production, use actual weather API
  
  const mockWeatherData = {
    punjab: {
      temperature: 28,
      humidity: 65,
      rainfall: 0,
      windSpeed: 12,
      forecast: 'partly_cloudy'
    },
    haryana: {
      temperature: 30,
      humidity: 60,
      rainfall: 0,
      windSpeed: 15,
      forecast: 'sunny'
    },
    uttar_pradesh: {
      temperature: 32,
      humidity: 70,
      rainfall: 5,
      windSpeed: 10,
      forecast: 'light_rain'
    },
    default: {
      temperature: 29,
      humidity: 62,
      rainfall: 0,
      windSpeed: 11,
      forecast: 'clear'
    }
  };
  
  const locationData = mockWeatherData[location?.toLowerCase().replace(' ', '_')] || mockWeatherData.default;
  
  // Generate alerts based on conditions
  const alerts = [];
  const recommendations = [];
  
  // Temperature alerts
  if (locationData.temperature > 35) {
    alerts.push({
      type: 'high_temperature',
      severity: 'warning',
      message: 'High temperature alert! Protect crops from heat stress'
    });
    recommendations.push('Increase irrigation frequency');
    recommendations.push('Apply mulch to conserve soil moisture');
  } else if (locationData.temperature < 10) {
    alerts.push({
      type: 'low_temperature',
      severity: 'warning',
      message: 'Low temperature alert! Risk of frost damage'
    });
    recommendations.push('Cover sensitive crops');
    recommendations.push('Avoid fertilizer application');
  }
  
  // Rainfall alerts
  if (locationData.rainfall > 20) {
    alerts.push({
      type: 'heavy_rain',
      severity: 'warning',
      message: 'Heavy rainfall expected! Risk of waterlogging'
    });
    recommendations.push('Ensure proper drainage in fields');
    recommendations.push('Postpone fertilizer application');
  } else if (locationData.rainfall > 0 && locationData.rainfall <= 20) {
    alerts.push({
      type: 'light_rain',
      severity: 'info',
      message: 'Light rainfall expected'
    });
    recommendations.push('Good time for transplanting');
  }
  
  // Humidity alerts
  if (locationData.humidity > 80) {
    alerts.push({
      type: 'high_humidity',
      severity: 'caution',
      message: 'High humidity - Risk of fungal diseases'
    });
    recommendations.push('Monitor crops for disease symptoms');
    recommendations.push('Ensure good air circulation');
  }
  
  // Wind alerts
  if (locationData.windSpeed > 30) {
    alerts.push({
      type: 'high_wind',
      severity: 'warning',
      message: 'Strong winds expected'
    });
    recommendations.push('Provide support to tall crops');
    recommendations.push('Secure greenhouse covers');
  }
  
  // Agriculture-specific recommendations based on current conditions
  const generalRecommendations = [];
  
  if (locationData.temperature >= 25 && locationData.temperature <= 35 && locationData.humidity >= 50 && locationData.humidity <= 70) {
    generalRecommendations.push('Ideal conditions for most crop growth');
    generalRecommendations.push('Good time for fertilizer application');
  }
  
  if (locationData.rainfall === 0 && locationData.humidity < 50) {
    generalRecommendations.push('Monitor soil moisture levels');
    generalRecommendations.push('Consider drip irrigation for water conservation');
  }
  
  return {
    location,
    currentConditions: {
      temperature: `${locationData.temperature}°C`,
      humidity: `${locationData.humidity}%`,
      rainfall: `${locationData.rainfall}mm`,
      windSpeed: `${locationData.windSpeed} km/h`,
      forecast: locationData.forecast.replace('_', ' ')
    },
    alerts: alerts.length > 0 ? alerts : [{ type: 'none', severity: 'info', message: 'No weather alerts' }],
    recommendations: recommendations.length > 0 ? recommendations : generalRecommendations,
    nextWeek: {
      summary: 'Generally stable weather expected',
      avgTemperature: `${locationData.temperature - 2} - ${locationData.temperature + 2}°C`,
      rainProbability: locationData.rainfall > 0 ? '40%' : '10%'
    },
    agriculturalAdvisory: {
      irrigation: locationData.rainfall > 10 ? 'Reduce irrigation' : 'Maintain regular irrigation',
      pestRisk: locationData.humidity > 70 ? 'High' : 'Low',
      diseaseRisk: locationData.humidity > 80 ? 'High' : locationData.humidity > 60 ? 'Medium' : 'Low',
      optimalActivities: getOptimalActivities(locationData)
    }
  };
};

const getOptimalActivities = (weatherData) => {
  const activities = [];
  
  if (weatherData.temperature >= 15 && weatherData.temperature <= 30 && weatherData.rainfall === 0) {
    activities.push('Sowing');
    activities.push('Transplanting');
  }
  
  if (weatherData.humidity < 70 && weatherData.rainfall === 0) {
    activities.push('Harvesting');
    activities.push('Threshing');
  }
  
  if (weatherData.temperature >= 20 && weatherData.humidity >= 60) {
    activities.push('Fertilizer application');
  }
  
  if (weatherData.rainfall > 0 && weatherData.rainfall < 10) {
    activities.push('Weeding');
  }
  
  return activities.length > 0 ? activities : ['Field monitoring', 'Soil preparation'];
};

module.exports = {
  getWeatherAlerts
};
