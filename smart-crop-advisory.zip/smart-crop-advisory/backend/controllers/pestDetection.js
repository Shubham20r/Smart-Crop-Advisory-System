// Pest detection module - simplified for MVP
// In production, this would use AI/ML models for actual image analysis

const analyzePest = async (imagePath) => {
  // Mock pest detection based on random simulation
  // In production, use TensorFlow.js or cloud-based AI service
  
  const commonPests = [
    {
      name: 'Aphids',
      confidence: 85,
      crop: 'Multiple crops',
      description: 'Small, soft-bodied insects that suck plant sap',
      symptoms: [
        'Curled or yellowing leaves',
        'Sticky honeydew on leaves',
        'Stunted plant growth'
      ],
      treatment: {
        organic: [
          'Spray neem oil solution (5ml per liter of water)',
          'Release ladybugs as natural predators',
          'Spray soap solution (5ml liquid soap per liter)'
        ],
        chemical: [
          'Imidacloprid 17.8% SL - 0.5ml/liter',
          'Thiamethoxam 25% WG - 0.5g/liter'
        ]
      },
      prevention: [
        'Regular field monitoring',
        'Remove weeds that host aphids',
        'Use reflective mulches'
      ]
    },
    {
      name: 'Whitefly',
      confidence: 78,
      crop: 'Cotton, Vegetables',
      description: 'Small white flying insects found on leaf undersides',
      symptoms: [
        'Yellow spots on leaves',
        'Sticky honeydew deposits',
        'Sooty mold growth'
      ],
      treatment: {
        organic: [
          'Yellow sticky traps',
          'Neem oil spray (10ml per liter)',
          'Garlic-chili spray'
        ],
        chemical: [
          'Acetamiprid 20% SP - 0.5g/liter',
          'Spiromesifen 22.9% SC - 1ml/liter'
        ]
      },
      prevention: [
        'Use insect-proof nets',
        'Maintain field hygiene',
        'Crop rotation'
      ]
    },
    {
      name: 'Bollworm',
      confidence: 72,
      crop: 'Cotton, Chickpea, Tomato',
      description: 'Caterpillar that bores into bolls, pods, and fruits',
      symptoms: [
        'Holes in bolls/fruits',
        'Damaged flower buds',
        'Frass near entry holes'
      ],
      treatment: {
        organic: [
          'Bacillus thuringiensis (Bt) spray',
          'Pheromone traps',
          'Hand picking of larvae'
        ],
        chemical: [
          'Emamectin benzoate 5% SG - 0.4g/liter',
          'Chlorantraniliprole 18.5% SC - 0.3ml/liter'
        ]
      },
      prevention: [
        'Deep summer plowing',
        'Timely sowing',
        'Install bird perches'
      ]
    },
    {
      name: 'Leaf Spot Disease',
      confidence: 68,
      crop: 'Various crops',
      description: 'Fungal disease causing spots on leaves',
      symptoms: [
        'Brown or black spots on leaves',
        'Yellow halos around spots',
        'Premature leaf drop'
      ],
      treatment: {
        organic: [
          'Remove infected leaves',
          'Copper-based fungicide',
          'Baking soda spray (1 tablespoon per liter)'
        ],
        chemical: [
          'Mancozeb 75% WP - 2g/liter',
          'Carbendazim 50% WP - 1g/liter'
        ]
      },
      prevention: [
        'Proper plant spacing',
        'Avoid overhead irrigation',
        'Crop rotation'
      ]
    },
    {
      name: 'No pest detected',
      confidence: 95,
      crop: 'N/A',
      description: 'Plant appears healthy',
      symptoms: [],
      treatment: {
        organic: [],
        chemical: []
      },
      prevention: [
        'Continue regular monitoring',
        'Maintain good agricultural practices'
      ]
    }
  ];
  
  // Simulate random detection (for MVP)
  const randomIndex = Math.floor(Math.random() * commonPests.length);
  const detectedPest = commonPests[randomIndex];
  
  // Add simulated confidence variation
  detectedPest.confidence = Math.max(60, Math.min(95, 
    detectedPest.confidence + Math.floor(Math.random() * 20) - 10));
  
  return {
    status: 'success',
    analysisResult: {
      pestDetected: detectedPest.name !== 'No pest detected',
      pest: detectedPest.name,
      confidence: `${detectedPest.confidence}%`,
      affectedCrops: detectedPest.crop,
      description: detectedPest.description,
      symptoms: detectedPest.symptoms,
      recommendations: {
        immediate: detectedPest.name !== 'No pest detected' 
          ? [
              'Isolate affected plants if possible',
              'Document the extent of infestation',
              'Begin treatment immediately'
            ]
          : ['Maintain regular monitoring'],
        treatment: detectedPest.treatment,
        prevention: detectedPest.prevention,
        followUp: [
          'Monitor daily for 7 days',
          'Reapply treatment if needed after 5-7 days',
          'Consult local agriculture officer if problem persists'
        ]
      }
    },
    additionalInfo: {
      severity: detectedPest.confidence > 80 ? 'High' : 
                detectedPest.confidence > 60 ? 'Medium' : 'Low',
      economicThreshold: 'Take action if more than 10% of plants are affected',
      bestTimeToTreat: 'Early morning or late evening',
      safetyPrecautions: [
        'Wear protective clothing when applying pesticides',
        'Keep chemicals away from water sources',
        'Follow label instructions carefully'
      ]
    }
  };
};

module.exports = {
  analyzePest
};
