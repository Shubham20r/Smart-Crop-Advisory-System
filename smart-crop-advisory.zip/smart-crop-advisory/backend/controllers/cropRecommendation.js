// Crop recommendation logic based on soil type, season, and other factors

const cropDatabase = {
  wheat: {
    soilTypes: ['loamy', 'clay loam', 'sandy loam'],
    seasons: ['rabi', 'winter'],
    waterRequirement: 'medium',
    growthDuration: '120-150 days',
    idealTemperature: '15-25°C'
  },
  rice: {
    soilTypes: ['clay', 'clay loam', 'silty clay'],
    seasons: ['kharif', 'summer'],
    waterRequirement: 'high',
    growthDuration: '120-140 days',
    idealTemperature: '20-35°C'
  },
  cotton: {
    soilTypes: ['black soil', 'alluvial', 'red soil'],
    seasons: ['kharif', 'summer'],
    waterRequirement: 'medium',
    growthDuration: '160-180 days',
    idealTemperature: '21-30°C'
  },
  sugarcane: {
    soilTypes: ['loamy', 'clay loam', 'black soil'],
    seasons: ['all', 'year-round'],
    waterRequirement: 'high',
    growthDuration: '10-12 months',
    idealTemperature: '20-35°C'
  },
  maize: {
    soilTypes: ['loamy', 'sandy loam', 'clay loam'],
    seasons: ['kharif', 'summer', 'rabi'],
    waterRequirement: 'medium',
    growthDuration: '80-110 days',
    idealTemperature: '21-27°C'
  },
  pulses: {
    soilTypes: ['loamy', 'sandy loam', 'clay loam'],
    seasons: ['rabi', 'kharif'],
    waterRequirement: 'low',
    growthDuration: '60-90 days',
    idealTemperature: '20-30°C'
  },
  vegetables: {
    soilTypes: ['loamy', 'sandy loam', 'alluvial'],
    seasons: ['all'],
    waterRequirement: 'medium',
    growthDuration: '30-90 days',
    idealTemperature: '15-30°C'
  }
};

const getRecommendation = ({ soilType, season, location, previousCrop, waterAvailability }) => {
  const recommendations = [];
  const reasons = [];
  
  // Find suitable crops based on soil type and season
  for (const [crop, details] of Object.entries(cropDatabase)) {
    let score = 0;
    const cropReasons = [];
    
    // Check soil compatibility
    if (details.soilTypes.includes(soilType?.toLowerCase())) {
      score += 3;
      cropReasons.push(`Suitable for ${soilType} soil`);
    }
    
    // Check season compatibility
    if (details.seasons.includes('all') || details.seasons.includes(season?.toLowerCase())) {
      score += 3;
      cropReasons.push(`Good for ${season} season`);
    }
    
    // Check water availability
    const waterMatch = 
      (waterAvailability === 'high' && details.waterRequirement !== 'high') ||
      (waterAvailability === 'medium' && details.waterRequirement !== 'high') ||
      (waterAvailability === 'low' && details.waterRequirement === 'low');
    
    if (waterMatch) {
      score += 2;
      cropReasons.push(`Matches water availability (${waterAvailability})`);
    }
    
    // Crop rotation benefit
    if (previousCrop && previousCrop.toLowerCase() !== crop) {
      if ((previousCrop === 'rice' && crop === 'pulses') ||
          (previousCrop === 'wheat' && crop === 'pulses') ||
          (previousCrop === 'cotton' && crop === 'wheat')) {
        score += 2;
        cropReasons.push('Good for crop rotation');
      }
    }
    
    if (score >= 5) {
      recommendations.push({
        crop: crop.charAt(0).toUpperCase() + crop.slice(1),
        score,
        details,
        reasons: cropReasons
      });
    }
  }
  
  // Sort by score
  recommendations.sort((a, b) => b.score - a.score);
  
  // Prepare response
  const topRecommendations = recommendations.slice(0, 3);
  
  return {
    recommendations: topRecommendations.map(r => ({
      crop: r.crop,
      suitabilityScore: Math.round((r.score / 10) * 100),
      reasons: r.reasons,
      growthDuration: r.details.growthDuration,
      waterRequirement: r.details.waterRequirement,
      idealTemperature: r.details.idealTemperature
    })),
    advisoryNotes: [
      'Test your soil before planting for optimal results',
      'Consider local market demand for selected crops',
      'Ensure proper seed quality from certified vendors',
      'Monitor weather forecasts regularly'
    ]
  };
};

const getFertilizerRecommendation = ({ crop, soilNPK, growthStage }) => {
  // Simple NPK recommendations based on crop and growth stage
  const fertilizerGuide = {
    wheat: {
      sowing: { N: 60, P: 30, K: 30 },
      vegetative: { N: 30, P: 0, K: 0 },
      flowering: { N: 30, P: 0, K: 20 }
    },
    rice: {
      sowing: { N: 40, P: 20, K: 20 },
      vegetative: { N: 40, P: 0, K: 0 },
      flowering: { N: 40, P: 0, K: 20 }
    },
    cotton: {
      sowing: { N: 40, P: 40, K: 20 },
      vegetative: { N: 40, P: 0, K: 0 },
      flowering: { N: 40, P: 0, K: 40 }
    },
    default: {
      sowing: { N: 50, P: 25, K: 25 },
      vegetative: { N: 25, P: 0, K: 0 },
      flowering: { N: 25, P: 0, K: 25 }
    }
  };
  
  const cropGuide = fertilizerGuide[crop?.toLowerCase()] || fertilizerGuide.default;
  const stageRecommendation = cropGuide[growthStage?.toLowerCase()] || cropGuide.sowing;
  
  // Adjust based on soil NPK if provided
  let adjustedN = stageRecommendation.N;
  let adjustedP = stageRecommendation.P;
  let adjustedK = stageRecommendation.K;
  
  if (soilNPK) {
    if (soilNPK.N === 'low') adjustedN *= 1.2;
    if (soilNPK.N === 'high') adjustedN *= 0.8;
    if (soilNPK.P === 'low') adjustedP *= 1.2;
    if (soilNPK.P === 'high') adjustedP *= 0.8;
    if (soilNPK.K === 'low') adjustedK *= 1.2;
    if (soilNPK.K === 'high') adjustedK *= 0.8;
  }
  
  return {
    recommendation: {
      nitrogen: Math.round(adjustedN),
      phosphorus: Math.round(adjustedP),
      potassium: Math.round(adjustedK),
      unit: 'kg/hectare'
    },
    applicationMethod: growthStage === 'sowing' 
      ? 'Apply as basal dose before sowing'
      : 'Apply as top dressing near root zone',
    organicAlternatives: [
      'Farm Yard Manure (FYM): 10-15 tonnes/hectare',
      'Vermicompost: 5-7 tonnes/hectare',
      'Green manure: Grow legumes and incorporate'
    ],
    precautions: [
      'Apply fertilizers when soil has adequate moisture',
      'Avoid application during heavy rain',
      'Maintain proper spacing from plant stem'
    ]
  };
};

module.exports = {
  getRecommendation,
  getFertilizerRecommendation
};
