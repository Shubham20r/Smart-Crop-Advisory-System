const express = require('express');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadPath = 'uploads/';
    if (!fs.existsSync(uploadPath)) {
      fs.mkdirSync(uploadPath);
    }
    cb(null, uploadPath);
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});

const upload = multer({ storage: storage });

// Import controllers
const cropRecommendation = require('./controllers/cropRecommendation');
const weatherService = require('./controllers/weatherService');
const pestDetection = require('./controllers/pestDetection');
const translations = require('./utils/translations');

// Routes
app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', message: 'Smart Crop Advisory API is running' });
});

// Crop recommendation endpoint
app.post('/api/crop-recommendation', (req, res) => {
  const { soilType, season, location, previousCrop, waterAvailability, language = 'en' } = req.body;
  
  const recommendation = cropRecommendation.getRecommendation({
    soilType,
    season,
    location,
    previousCrop,
    waterAvailability
  });
  
  const translatedRecommendation = translations.translate(recommendation, language);
  res.json(translatedRecommendation);
});

// Weather alerts endpoint
app.get('/api/weather/:location', async (req, res) => {
  try {
    const { location } = req.params;
    const { language = 'en' } = req.query;
    const weatherData = await weatherService.getWeatherAlerts(location);
    const translatedData = translations.translate(weatherData, language);
    res.json(translatedData);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch weather data' });
  }
});

// Pest detection endpoint
app.post('/api/pest-detection', upload.single('image'), async (req, res) => {
  try {
    const { language = 'en' } = req.body;
    const imagePath = req.file.path;
    
    const pestAnalysis = await pestDetection.analyzePest(imagePath);
    const translatedAnalysis = translations.translate(pestAnalysis, language);
    
    // Clean up uploaded file
    fs.unlinkSync(imagePath);
    
    res.json(translatedAnalysis);
  } catch (error) {
    res.status(500).json({ error: 'Failed to analyze image' });
  }
});

// Fertilizer recommendation endpoint
app.post('/api/fertilizer-recommendation', (req, res) => {
  const { crop, soilNPK, growthStage, language = 'en' } = req.body;
  
  const recommendation = cropRecommendation.getFertilizerRecommendation({
    crop,
    soilNPK,
    growthStage
  });
  
  const translatedRecommendation = translations.translate(recommendation, language);
  res.json(translatedRecommendation);
});

// Market prices endpoint (mock data for MVP)
app.get('/api/market-prices/:crop', (req, res) => {
  const { crop } = req.params;
  const { language = 'en' } = req.query;
  
  const prices = {
    wheat: { min: 2000, max: 2200, avg: 2100, unit: 'Rs/quintal' },
    rice: { min: 1800, max: 2000, avg: 1900, unit: 'Rs/quintal' },
    cotton: { min: 5500, max: 6000, avg: 5750, unit: 'Rs/quintal' },
    sugarcane: { min: 280, max: 320, avg: 300, unit: 'Rs/quintal' }
  };
  
  const priceData = prices[crop.toLowerCase()] || { message: 'Price data not available' };
  const translatedData = translations.translate({ crop, ...priceData }, language);
  res.json(translatedData);
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
