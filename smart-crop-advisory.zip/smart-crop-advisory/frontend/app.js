// API Base URL - Update this when deploying
const API_BASE_URL = 'http://localhost:5000/api';

// Current language
let currentLanguage = 'en';

// Translation dictionary for UI elements
const uiTranslations = {
    'crop-tab': { en: 'Crop Advisory', hi: 'फसल सलाह' },
    'weather-tab': { en: 'Weather', hi: 'मौसम' },
    'pest-tab': { en: 'Pest Detection', hi: 'कीट पहचान' },
    'fertilizer-tab': { en: 'Fertilizer', hi: 'उर्वरक' },
    'market-tab': { en: 'Market Prices', hi: 'बाजार भाव' },
    'crop-title': { en: 'Get Crop Recommendations', hi: 'फसल सिफारिशें प्राप्त करें' },
    'weather-title': { en: 'Weather & Agricultural Advisory', hi: 'मौसम और कृषि सलाह' },
    'pest-title': { en: 'Upload Image for Pest Detection', hi: 'कीट पहचान के लिए तस्वीर अपलोड करें' },
    'fertilizer-title': { en: 'Fertilizer Recommendations', hi: 'उर्वरक सिफारिशें' },
    'market-title': { en: 'Current Market Prices', hi: 'वर्तमान बाजार भाव' },
    'soil-type': { en: 'Soil Type:', hi: 'मिट्टी का प्रकार:' },
    'season': { en: 'Season:', hi: 'मौसम:' },
    'location': { en: 'Location:', hi: 'स्थान:' },
    'previous-crop': { en: 'Previous Crop:', hi: 'पिछली फसल:' },
    'water-availability': { en: 'Water Availability:', hi: 'पानी की उपलब्धता:' },
    'get-recommendations': { en: 'Get Recommendations', hi: 'सिफारिशें प्राप्त करें' },
    'get-weather': { en: 'Get Weather Info', hi: 'मौसम जानकारी प्राप्त करें' },
    'upload-image': { en: 'Upload Plant/Leaf Image:', hi: 'पौधे/पत्ती की तस्वीर अपलोड करें:' },
    'analyze': { en: 'Analyze', hi: 'विश्लेषण करें' },
    'crop': { en: 'Crop:', hi: 'फसल:' },
    'growth-stage': { en: 'Growth Stage:', hi: 'विकास चरण:' },
    'get-fertilizer': { en: 'Get Recommendations', hi: 'सिफारिशें प्राप्त करें' },
    'get-prices': { en: 'Get Prices', hi: 'भाव प्राप्त करें' },
    'loading': { en: 'Loading...', hi: 'लोड हो रहा है...' }
};

// Set language and update UI
function setLanguage(lang) {
    currentLanguage = lang;
    
    // Update language buttons
    document.querySelectorAll('.lang-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    event.target.classList.add('active');
    
    // Update UI translations
    document.querySelectorAll('[data-translate]').forEach(element => {
        const key = element.getAttribute('data-translate');
        if (uiTranslations[key]) {
            element.textContent = uiTranslations[key][lang];
        }
    });
}

// Show/hide tabs
function showTab(tabName) {
    // Update tab buttons
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    event.target.closest('.tab-btn').classList.add('active');
    
    // Update tab panels
    document.querySelectorAll('.tab-panel').forEach(panel => {
        panel.classList.remove('active');
    });
    document.getElementById(`${tabName}-tab`).classList.add('active');
}

// Show/hide loader
function showLoader(show = true) {
    const loader = document.getElementById('loader');
    if (show) {
        loader.classList.remove('hidden');
    } else {
        loader.classList.add('hidden');
    }
}

// Display results
function displayResults(containerId, html) {
    const container = document.getElementById(containerId);
    container.innerHTML = html;
    container.classList.add('show');
}

// Format crop recommendations
function formatCropRecommendations(data) {
    let html = '<h4>Recommended Crops:</h4>';
    
    if (data.recommendations && data.recommendations.length > 0) {
        data.recommendations.forEach(rec => {
            html += `
                <div class="result-card">
                    <h4>${rec.crop} <span class="score-badge">${rec.suitabilityScore}% Match</span></h4>
                    <p><strong>Growth Duration:</strong> ${rec.growthDuration}</p>
                    <p><strong>Water Requirement:</strong> ${rec.waterRequirement}</p>
                    <p><strong>Ideal Temperature:</strong> ${rec.idealTemperature}</p>
                    <p><strong>Why this crop?</strong></p>
                    <ul class="result-list">
                        ${rec.reasons.map(r => `<li>${r}</li>`).join('')}
                    </ul>
                </div>
            `;
        });
    }
    
    if (data.advisoryNotes) {
        html += '<h4>Advisory Notes:</h4><ul class="result-list">';
        data.advisoryNotes.forEach(note => {
            html += `<li>${note}</li>`;
        });
        html += '</ul>';
    }
    
    return html;
}

// Format weather data
function formatWeatherData(data) {
    let html = '<h4>Current Weather Conditions:</h4>';
    
    if (data.currentConditions) {
        html += `
            <div class="result-card">
                <p><strong>Temperature:</strong> ${data.currentConditions.temperature}</p>
                <p><strong>Humidity:</strong> ${data.currentConditions.humidity}</p>
                <p><strong>Rainfall:</strong> ${data.currentConditions.rainfall}</p>
                <p><strong>Wind Speed:</strong> ${data.currentConditions.windSpeed}</p>
                <p><strong>Forecast:</strong> ${data.currentConditions.forecast}</p>
            </div>
        `;
    }
    
    if (data.alerts && data.alerts.length > 0) {
        html += '<h4>Weather Alerts:</h4>';
        data.alerts.forEach(alert => {
            html += `<div class="alert-card ${alert.severity}">${alert.message}</div>`;
        });
    }
    
    if (data.recommendations && data.recommendations.length > 0) {
        html += '<h4>Recommendations:</h4><ul class="result-list">';
        data.recommendations.forEach(rec => {
            html += `<li>${rec}</li>`;
        });
        html += '</ul>';
    }
    
    if (data.agriculturalAdvisory) {
        html += `
            <h4>Agricultural Advisory:</h4>
            <div class="result-card">
                <p><strong>Irrigation:</strong> ${data.agriculturalAdvisory.irrigation}</p>
                <p><strong>Pest Risk:</strong> ${data.agriculturalAdvisory.pestRisk}</p>
                <p><strong>Disease Risk:</strong> ${data.agriculturalAdvisory.diseaseRisk}</p>
                <p><strong>Optimal Activities:</strong> ${data.agriculturalAdvisory.optimalActivities.join(', ')}</p>
            </div>
        `;
    }
    
    return html;
}

// Format pest detection results
function formatPestResults(data) {
    let html = '';
    
    if (data.analysisResult) {
        const result = data.analysisResult;
        html += `
            <h4>Analysis Results:</h4>
            <div class="result-card">
                <h4>${result.pestDetected ? '⚠️ Pest Detected' : '✅ No Pest Detected'}</h4>
                <p><strong>Identified:</strong> ${result.pest} (${result.confidence} confidence)</p>
                <p><strong>Affected Crops:</strong> ${result.affectedCrops}</p>
                <p><strong>Description:</strong> ${result.description}</p>
            </div>
        `;
        
        if (result.symptoms && result.symptoms.length > 0) {
            html += '<h4>Symptoms:</h4><ul class="result-list">';
            result.symptoms.forEach(symptom => {
                html += `<li>${symptom}</li>`;
            });
            html += '</ul>';
        }
        
        if (result.recommendations) {
            if (result.recommendations.treatment) {
                html += '<h4>Treatment Options:</h4>';
                
                if (result.recommendations.treatment.organic && result.recommendations.treatment.organic.length > 0) {
                    html += '<p><strong>Organic Methods:</strong></p><ul class="result-list">';
                    result.recommendations.treatment.organic.forEach(method => {
                        html += `<li>${method}</li>`;
                    });
                    html += '</ul>';
                }
                
                if (result.recommendations.treatment.chemical && result.recommendations.treatment.chemical.length > 0) {
                    html += '<p><strong>Chemical Methods:</strong></p><ul class="result-list">';
                    result.recommendations.treatment.chemical.forEach(method => {
                        html += `<li>${method}</li>`;
                    });
                    html += '</ul>';
                }
            }
            
            if (result.recommendations.prevention && result.recommendations.prevention.length > 0) {
                html += '<h4>Prevention:</h4><ul class="result-list">';
                result.recommendations.prevention.forEach(method => {
                    html += `<li>${method}</li>`;
                });
                html += '</ul>';
            }
        }
    }
    
    if (data.additionalInfo) {
        html += `
            <h4>Additional Information:</h4>
            <div class="result-card">
                <p><strong>Severity:</strong> ${data.additionalInfo.severity}</p>
                <p><strong>Economic Threshold:</strong> ${data.additionalInfo.economicThreshold}</p>
                <p><strong>Best Time to Treat:</strong> ${data.additionalInfo.bestTimeToTreat}</p>
            </div>
        `;
    }
    
    return html;
}

// Format fertilizer recommendations
function formatFertilizerResults(data) {
    let html = '<h4>Fertilizer Recommendations:</h4>';
    
    if (data.recommendation) {
        html += `
            <div class="result-card">
                <p><strong>Nitrogen (N):</strong> ${data.recommendation.nitrogen} ${data.recommendation.unit}</p>
                <p><strong>Phosphorus (P):</strong> ${data.recommendation.phosphorus} ${data.recommendation.unit}</p>
                <p><strong>Potassium (K):</strong> ${data.recommendation.potassium} ${data.recommendation.unit}</p>
                <p><strong>Application Method:</strong> ${data.applicationMethod}</p>
            </div>
        `;
    }
    
    if (data.organicAlternatives && data.organicAlternatives.length > 0) {
        html += '<h4>Organic Alternatives:</h4><ul class="result-list">';
        data.organicAlternatives.forEach(alt => {
            html += `<li>${alt}</li>`;
        });
        html += '</ul>';
    }
    
    if (data.precautions && data.precautions.length > 0) {
        html += '<h4>Precautions:</h4><ul class="result-list">';
        data.precautions.forEach(precaution => {
            html += `<li>${precaution}</li>`;
        });
        html += '</ul>';
    }
    
    return html;
}

// Format market prices
function formatMarketPrices(data) {
    let html = '<h4>Market Price Information:</h4>';
    
    html += `
        <div class="result-card">
            <h4>${data.crop}</h4>
            <p><strong>Minimum Price:</strong> ₹${data.min} ${data.unit}</p>
            <p><strong>Maximum Price:</strong> ₹${data.max} ${data.unit}</p>
            <p><strong>Average Price:</strong> ₹${data.avg} ${data.unit}</p>
        </div>
    `;
    
    return html;
}

// Initialize event listeners
document.addEventListener('DOMContentLoaded', function() {
    // Crop recommendation form
    document.getElementById('crop-form').addEventListener('submit', async function(e) {
        e.preventDefault();
        showLoader(true);
        
        const formData = new FormData(e.target);
        const data = Object.fromEntries(formData);
        data.language = currentLanguage;
        
        try {
            const response = await fetch(`${API_BASE_URL}/crop-recommendation`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
            
            const result = await response.json();
            displayResults('crop-results', formatCropRecommendations(result));
        } catch (error) {
            displayResults('crop-results', '<div class="alert-card warning">Error fetching recommendations. Please try again.</div>');
        } finally {
            showLoader(false);
        }
    });
    
    // Weather form
    document.getElementById('weather-form').addEventListener('submit', async function(e) {
        e.preventDefault();
        showLoader(true);
        
        const location = e.target.location.value;
        
        try {
            const response = await fetch(`${API_BASE_URL}/weather/${location}?language=${currentLanguage}`);
            const result = await response.json();
            displayResults('weather-results', formatWeatherData(result));
        } catch (error) {
            displayResults('weather-results', '<div class="alert-card warning">Error fetching weather data. Please try again.</div>');
        } finally {
            showLoader(false);
        }
    });
    
    // Pest detection form
    document.getElementById('pest-form').addEventListener('submit', async function(e) {
        e.preventDefault();
        showLoader(true);
        
        const formData = new FormData();
        formData.append('image', e.target.image.files[0]);
        formData.append('language', currentLanguage);
        
        try {
            const response = await fetch(`${API_BASE_URL}/pest-detection`, {
                method: 'POST',
                body: formData
            });
            
            const result = await response.json();
            displayResults('pest-results', formatPestResults(result));
        } catch (error) {
            displayResults('pest-results', '<div class="alert-card warning">Error analyzing image. Please try again.</div>');
        } finally {
            showLoader(false);
        }
    });
    
    // Image preview
    document.querySelector('input[name="image"]').addEventListener('change', function(e) {
        const preview = document.getElementById('image-preview');
        const file = e.target.files[0];
        
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                preview.innerHTML = `<img src="${e.target.result}" alt="Preview">`;
            };
            reader.readAsDataURL(file);
        }
    });
    
    // Fertilizer form
    document.getElementById('fertilizer-form').addEventListener('submit', async function(e) {
        e.preventDefault();
        showLoader(true);
        
        const formData = new FormData(e.target);
        const data = {
            crop: formData.get('crop'),
            growthStage: formData.get('growthStage'),
            language: currentLanguage
        };
        
        // Add NPK values if provided
        if (formData.get('soilN') || formData.get('soilP') || formData.get('soilK')) {
            data.soilNPK = {
                N: formData.get('soilN') || 'medium',
                P: formData.get('soilP') || 'medium',
                K: formData.get('soilK') || 'medium'
            };
        }
        
        try {
            const response = await fetch(`${API_BASE_URL}/fertilizer-recommendation`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
            
            const result = await response.json();
            displayResults('fertilizer-results', formatFertilizerResults(result));
        } catch (error) {
            displayResults('fertilizer-results', '<div class="alert-card warning">Error fetching recommendations. Please try again.</div>');
        } finally {
            showLoader(false);
        }
    });
    
    // Market prices form
    document.getElementById('market-form').addEventListener('submit', async function(e) {
        e.preventDefault();
        showLoader(true);
        
        const crop = e.target.crop.value;
        
        try {
            const response = await fetch(`${API_BASE_URL}/market-prices/${crop}?language=${currentLanguage}`);
            const result = await response.json();
            displayResults('market-results', formatMarketPrices(result));
        } catch (error) {
            displayResults('market-results', '<div class="alert-card warning">Error fetching price data. Please try again.</div>');
        } finally {
            showLoader(false);
        }
    });
});
